import React from 'react';

interface EnterOverlayProps {
  onEnter: () => void;
  visible: boolean;
}

const EnterOverlay: React.FC<EnterOverlayProps> = ({ onEnter, visible }) => {
  if (!visible) return null;

  return (
    <div 
      onClick={onEnter}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black cursor-pointer select-none"
    >
      <div className="text-center animate-pulse-slow">
        <p className="text-white text-xl md:text-2xl font-mono tracking-[0.5em] text-shadow-glow">
          CLICK TO ENTER
        </p>
      </div>
    </div>
  );
};

export default EnterOverlay;