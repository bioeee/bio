import React, { useState } from 'react';
import { ProfileConfig, SocialLink } from '../types';
import { X, Sparkles, Settings, Eye } from './Icons';
import { generateAestheticBio } from '../services/geminiService';

interface ConfigPanelProps {
  config: ProfileConfig;
  updateConfig: (newConfig: ProfileConfig) => void;
  isOpen: boolean;
  onClose: () => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ config, updateConfig, isOpen, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [vibePrompt, setVibePrompt] = useState('dark, mysterious, heartbroken');

  const handleChange = (field: keyof ProfileConfig, value: any) => {
    updateConfig({ ...config, [field]: value });
  };

  const handleGenerateBio = async () => {
    setIsGenerating(true);
    const newBio = await generateAestheticBio(config.username, vibePrompt);
    handleChange('bio', newBio);
    setIsGenerating(false);
  };

  const parseYoutubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const handleAudioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    const id = parseYoutubeId(val);
    if (id) {
      handleChange('youtubeAudioId', id);
    } else {
        if(val.length === 11) handleChange('youtubeAudioId', val);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-[60] w-full md:w-96 bg-zinc-900/95 backdrop-blur-xl border-l border-white/10 p-6 overflow-y-auto transition-transform duration-300">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold font-sans text-white">Configuration</h2>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="space-y-6">
        {/* Username */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Display Name</label>
          <input 
            type="text" 
            value={config.username}
            onChange={(e) => handleChange('username', e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none transition-colors"
          />
        </div>

        {/* Bio + Gemini */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Bio</label>
          <textarea 
            value={config.bio}
            onChange={(e) => handleChange('bio', e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none transition-colors min-h-[80px]"
          />
          
          <div className="bg-zinc-800/50 rounded-lg p-3 space-y-2 border border-white/5">
             <div className="flex items-center gap-2 text-xs text-purple-300">
                <Sparkles className="w-3 h-3" />
                <span>AI Generator</span>
             </div>
             <input 
                type="text"
                value={vibePrompt}
                onChange={(e) => setVibePrompt(e.target.value)}
                placeholder="Vibe (e.g., dark, emo, happy)"
                className="w-full bg-black/30 border border-white/5 rounded px-2 py-1 text-xs mb-2"
             />
             <button 
               onClick={handleGenerateBio}
               disabled={isGenerating}
               className="w-full py-1.5 bg-purple-600/20 hover:bg-purple-600/40 text-purple-200 text-xs rounded border border-purple-500/30 transition-all"
             >
               {isGenerating ? 'Generating...' : 'Generate Aesthetic Bio'}
             </button>
          </div>
        </div>

        {/* Avatar */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Avatar URL</label>
          <input 
            type="text" 
            value={config.avatarUrl}
            onChange={(e) => handleChange('avatarUrl', e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none"
            placeholder="https://..."
          />
        </div>

        {/* Background */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Background URL (Image/MP4)</label>
          <input 
            type="text" 
            value={config.backgroundUrl}
            onChange={(e) => handleChange('backgroundUrl', e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none"
            placeholder="https://... (mp4 for video)"
          />
          <div className="flex gap-2 text-xs">
            <button 
              onClick={() => handleChange('backgroundType', 'video')}
              className={`px-3 py-1 rounded border ${config.backgroundType === 'video' ? 'bg-white text-black border-white' : 'border-white/20 text-zinc-400'}`}
            >
              Video
            </button>
            <button 
              onClick={() => handleChange('backgroundType', 'image')}
              className={`px-3 py-1 rounded border ${config.backgroundType === 'image' ? 'bg-white text-black border-white' : 'border-white/20 text-zinc-400'}`}
            >
              Image
            </button>
          </div>
        </div>

        {/* Discord Server */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Discord Server Invite</label>
          <input 
            type="text" 
            value={config.discordServerUrl || ''}
            onChange={(e) => handleChange('discordServerUrl', e.target.value)}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none"
            placeholder="https://discord.gg/..."
          />
        </div>

        {/* Audio */}
        <div className="space-y-2">
          <label className="text-xs font-mono text-zinc-400 uppercase">Background Music (YouTube URL)</label>
          <input 
            type="text" 
            defaultValue={`https://youtube.com/watch?v=${config.youtubeAudioId}`}
            onBlur={handleAudioChange}
            className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm focus:border-white/40 outline-none"
            placeholder="Paste YouTube Link"
          />
          <p className="text-[10px] text-zinc-500">Audio plays automatically after entering.</p>
        </div>

        {/* Secret View Editor */}
        <div className="space-y-2 pt-2 border-t border-dashed border-white/10">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono text-zinc-500 uppercase flex items-center gap-2">
              <Eye className="w-3 h-3" /> 
              Admin View Override
            </label>
            <input 
              type="checkbox"
              checked={config.showViews}
              onChange={(e) => handleChange('showViews', e.target.checked)}
              className="accent-white h-3 w-3"
              title="Toggle Visibility"
            />
          </div>
          <input 
            type="number" 
            value={config.views}
            onChange={(e) => handleChange('views', parseInt(e.target.value) || 0)}
            className="w-full bg-black/80 border border-zinc-700 text-green-500 font-mono rounded-lg p-2 text-xs focus:border-green-500/50 outline-none"
            placeholder="1337"
          />
        </div>

        {/* Socials */}
        <div className="space-y-2 border-t border-white/10 pt-4">
           <label className="text-xs font-mono text-zinc-400 uppercase">Social Links</label>
           {config.socials.map((social, index) => (
             <div key={social.id} className="flex gap-2">
                <select 
                  value={social.platform}
                  onChange={(e) => {
                    const newSocials = [...config.socials];
                    newSocials[index].platform = e.target.value as any;
                    handleChange('socials', newSocials);
                  }}
                  className="bg-black/50 border border-white/10 rounded px-2 text-xs"
                >
                  <option value="discord">Discord</option>
                  <option value="twitter">Twitter</option>
                  <option value="tiktok">TikTok</option>
                  <option value="instagram">Instagram</option>
                  <option value="youtube">YouTube</option>
                  <option value="github">GitHub</option>
                </select>
                <input 
                  type="text"
                  value={social.url}
                  onChange={(e) => {
                    const newSocials = [...config.socials];
                    newSocials[index].url = e.target.value;
                    handleChange('socials', newSocials);
                  }}
                  placeholder="URL or Username"
                  className="flex-1 bg-black/50 border border-white/10 rounded px-2 py-1 text-xs"
                />
             </div>
           ))}
           <button 
             onClick={() => {
               const newLink: SocialLink = { id: Date.now().toString(), platform: 'generic', url: '' };
               handleChange('socials', [...config.socials, newLink]);
             }}
             className="text-xs text-blue-400 hover:text-blue-300"
           >
             + Add Link
           </button>
        </div>
      </div>
    </div>
  );
};

export default ConfigPanel;