import React from 'react';
import { 
  Twitter, 
  Instagram, 
  Github, 
  Youtube, 
  Link as LinkIcon, 
  Music, 
  Disc,
  Settings,
  X,
  Play,
  Eye,
  Sparkles,
  Share2
} from 'lucide-react';

// Custom icons that might not be in the lucide set or need specific styling
export const DiscordIcon = ({ className }: { className?: string }) => (
  <svg 
    className={className} 
    viewBox="0 0 127.14 96.36" 
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.29,105.29,0,0,0,19.36,8.07C2.05,37.31-4.7,66.91,6.81,95.55a106.66,106.66,0,0,0,32.33,16,77.6,77.6,0,0,0,6.56-10.74A92.05,92.05,0,0,1,16.59,85.19,1.75,1.75,0,0,1,16.29,82a72.5,72.5,0,0,0,69.56,0,1.75,1.75,0,0,1-.3,3.15,92.05,92.05,0,0,1-29.11,15.65,76.5,76.5,0,0,0,6.56,10.74,106.66,106.66,0,0,0,32.33-16C134.49,60.14,125,32.48,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
  </svg>
);

export const TikTokIcon = ({ className }: { className?: string }) => (
  <svg 
    className={className} 
    viewBox="0 0 24 24" 
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
  </svg>
);

export { 
  Twitter, 
  Instagram, 
  Github, 
  Youtube, 
  LinkIcon, 
  Music, 
  Disc,
  Settings,
  X,
  Play,
  Eye,
  Sparkles,
  Share2
};