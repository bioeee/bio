import React, { useState, useEffect, useRef } from 'react';
import EnterOverlay from './components/EnterOverlay';
import ConfigPanel from './components/ConfigPanel';
import { DiscordIcon, TikTokIcon, Twitter, Instagram, Github, Youtube, Settings, Eye, Disc } from './components/Icons';
import { ProfileConfig } from './types';

// Default configuration to simulate a filled profile
const DEFAULT_CONFIG: ProfileConfig = {
  username: "ghost",
  bio: "lost in the digital void.\nfrontend engineer & dreamer.",
  avatarUrl: "https://picsum.photos/200/200",
  backgroundUrl: "https://videos.pexels.com/video-files/5466723/5466723-hd_1920_1080_25fps.mp4",
  backgroundType: "video",
  youtubeAudioId: "jfKfPfyJRdk", // Lofi Girl or similar safe default
  accentColor: "#ffffff",
  showViews: true,
  views: 1337,
  socials: [
    { id: '1', platform: 'discord', url: 'https://discord.com' },
    { id: '2', platform: 'github', url: 'https://github.com' },
    { id: '3', platform: 'twitter', url: 'https://twitter.com' },
  ]
};

const App: React.FC = () => {
  const [hasEntered, setHasEntered] = useState(false);
  const [config, setConfig] = useState<ProfileConfig>(DEFAULT_CONFIG);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  
  // Audio Player Ref
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // View Counter Increment Logic
  useEffect(() => {
    if (hasEntered) {
      setConfig(prev => ({
        ...prev,
        views: prev.views + 1
      }));
    }
  }, [hasEntered]);

  // Secret Key Listener (Alt + X)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check for Alt + X to toggle menu visibility as a shortcut
      if (e.altKey && e.key.toLowerCase() === 'x') {
        e.preventDefault();
        setIsConfigOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleEnter = () => {
    setHasEntered(true);
  };

  const getIcon = (platform: string) => {
    const cls = "w-6 h-6 hover:text-gray-300 transition-colors duration-300";
    switch(platform) {
      case 'discord': return <DiscordIcon className={cls} />;
      case 'tiktok': return <TikTokIcon className={cls} />;
      case 'twitter': return <Twitter className={cls} />;
      case 'instagram': return <Instagram className={cls} />;
      case 'github': return <Github className={cls} />;
      case 'youtube': return <Youtube className={cls} />;
      default: return <Disc className={cls} />;
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden text-white font-sans selection:bg-white/30 selection:text-white">
      
      {/* Background Media */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black/40 z-10" /> {/* Overlay for text readability */}
        {config.backgroundType === 'video' ? (
          <video 
            src={config.backgroundUrl} 
            autoPlay 
            loop 
            muted 
            playsInline 
            className="w-full h-full object-cover"
          />
        ) : (
          <img 
            src={config.backgroundUrl} 
            alt="bg" 
            className="w-full h-full object-cover"
          />
        )}
      </div>

      {/* CRT Scanline Effect */}
      <div className="scanlines" />

      {/* Customize Button - Visible after enter */}
      {hasEntered && (
        <button 
          onClick={() => setIsConfigOpen(true)}
          className="fixed top-6 left-6 z-40 flex items-center gap-2 px-4 py-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-full hover:bg-white/10 transition-all duration-300 group animate-fade-in"
        >
          <Settings className="w-4 h-4 text-white/70 group-hover:rotate-90 transition-transform duration-500" />
          <span className="text-xs font-mono uppercase tracking-widest text-white/80">Personnaliser</span>
        </button>
      )}

      {/* Configuration Panel */}
      <ConfigPanel 
        config={config} 
        updateConfig={setConfig} 
        isOpen={isConfigOpen} 
        onClose={() => setIsConfigOpen(false)} 
      />

      {/* Enter Screen */}
      <EnterOverlay visible={!hasEntered} onEnter={handleEnter} />

      {/* Main Profile Content */}
      {hasEntered && (
        <main className="relative z-10 min-h-screen flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-md">
            
            {/* Glass Card */}
            <div className="glass-panel rounded-2xl p-8 md:p-10 shadow-2xl backdrop-blur-xl animate-slide-up flex flex-col items-center text-center">
              
              {/* Avatar */}
              <div className="relative group mb-6">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-white/50 to-gray-500/50 rounded-full opacity-75 group-hover:opacity-100 blur transition duration-1000 group-hover:duration-200"></div>
                <img 
                  src={config.avatarUrl} 
                  alt={config.username} 
                  className="relative w-32 h-32 rounded-full object-cover border-2 border-white/10 shadow-xl"
                />
              </div>

              {/* Username */}
              <h1 className="text-3xl font-bold tracking-tight mb-2 drop-shadow-md">
                {config.username}
              </h1>

              {/* Bio */}
              <div className="mb-6 space-y-2">
                {config.bio.split('\n').map((line, i) => (
                  <p key={i} className="text-sm md:text-base text-gray-300 font-mono leading-relaxed">
                    {line}
                  </p>
                ))}
              </div>

              {/* Social Links */}
              <div className="flex flex-wrap justify-center gap-6 mb-8">
                {config.socials.map((social) => (
                  <a 
                    key={social.id}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transform hover:scale-110 transition-transform duration-200"
                    title={social.platform}
                  >
                    {getIcon(social.platform)}
                  </a>
                ))}
              </div>

              {/* Special Discord Server Button */}
              {config.discordServerUrl && (
                <div className="mb-8 w-full">
                  <a 
                    href={config.discordServerUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-3 w-full py-3 px-4 bg-[#5865F2]/20 hover:bg-[#5865F2]/40 border border-[#5865F2]/50 rounded-xl transition-all duration-300 group"
                  >
                    <DiscordIcon className="w-5 h-5 text-[#5865F2] group-hover:text-white transition-colors" />
                    <span className="font-mono text-sm font-bold tracking-wider group-hover:text-white text-gray-200">JOIN SERVER</span>
                  </a>
                </div>
              )}

              {/* Views Counter (Aesthetic element) */}
              {config.showViews && (
                <div className="flex items-center gap-2 text-xs text-gray-500 font-mono mt-2" title="Total Views">
                  <Eye className="w-3 h-3" />
                  <span>{config.views.toLocaleString()}</span>
                </div>
              )}
            </div>

            {/* Hidden Audio Player */}
            <div className="fixed bottom-0 right-0 w-1 h-1 opacity-0 pointer-events-none overflow-hidden">
               <iframe
                 ref={iframeRef}
                 width="1"
                 height="1"
                 src={`https://www.youtube.com/embed/${config.youtubeAudioId}?autoplay=1&loop=1&playlist=${config.youtubeAudioId}&controls=0`}
                 title="Audio Player"
                 allow="autoplay"
               />
            </div>

          </div>
        </main>
      )}
    </div>
  );
};

export default App;