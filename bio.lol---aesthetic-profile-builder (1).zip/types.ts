export interface SocialLink {
  id: string;
  platform: 'discord' | 'twitter' | 'instagram' | 'tiktok' | 'youtube' | 'github' | 'generic';
  url: string;
  label?: string;
}

export interface ProfileConfig {
  username: string;
  bio: string;
  avatarUrl: string;
  backgroundUrl: string; // Image or Video URL
  backgroundType: 'image' | 'video';
  youtubeAudioId: string; // The ID from a youtube URL
  socials: SocialLink[];
  discordServerUrl?: string; // Specific link for a Discord Server
  accentColor: string;
  showViews: boolean;
  views: number;
}