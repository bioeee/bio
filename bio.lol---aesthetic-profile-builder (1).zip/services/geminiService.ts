import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

export const generateAestheticBio = async (username: string, vibe: string): Promise<string> => {
  if (!apiKey) {
    console.warn("API Key not found for Gemini");
    return "Error: API Key missing. Configure process.env.API_KEY";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      Create a short, mysterious, and aesthetic bio description for a user named "${username}".
      The vibe they want is: "${vibe}".
      
      Style guidelines:
      - Max 150 characters.
      - Use lowercase styling often found on "guns.lol" or aesthetic profiles.
      - Can include 1 or 2 relevant edgy/dark emojis.
      - Be cryptic but cool.
      - Return ONLY the bio text.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Gemini generation error:", error);
    return "just existing.";
  }
};